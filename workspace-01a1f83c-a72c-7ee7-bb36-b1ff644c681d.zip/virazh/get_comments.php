<?php
require('header.php');
?>
<h2 class="mb-4">Отзывы о нас</h2>
<?php
@$fp = fopen("comments.txt", "r");
if (!$fp || filesize("comments.txt") == 0) {
	if ($fp) {
		fclose($fp);
	}
	echo '<p class="fw-semibold">Отзывов пока нет. Оставьте свой отзыв первым!</p>';
	require('footer.php');
	exit;
}

$hasComments = false;
echo '<div class="d-flex flex-column align-items-center gap-3">';
while (!feof($fp)) {
	$comm = fgets($fp);
	if ($comm === false) {
		break;
	}
	$arr_comm = explode("\t", trim($comm, "\r\n"));
	if (!empty($arr_comm[0]) && count($arr_comm) >= 4) {
		$hasComments = true;
		?>
		<section class="card my-1 shadow-sm" style="width: 320px;">
			<span class="avatar avatar-subtle theme-accent"><?= htmlspecialchars($arr_comm[1], ENT_QUOTES, 'UTF-8') ?></span>
			<div class="card-body">
				<h4 class="card-title h6">Тема: <?= htmlspecialchars($arr_comm[2], ENT_QUOTES, 'UTF-8') ?></h4>
				<p class="card-text"><?= htmlspecialchars($arr_comm[3], ENT_QUOTES, 'UTF-8') ?></p>
				<p class="card-text"><b><?= htmlspecialchars($arr_comm[0], ENT_QUOTES, 'UTF-8') ?></b></p>
			</div>
		</section>
		<?php
	}
}
echo '</div>';
fclose($fp);

if (!$hasComments) {
	echo '<p class="fw-semibold">Отзывов пока нет. Оставьте свой отзыв первым!</p>';
}

require('footer.php');
?>
