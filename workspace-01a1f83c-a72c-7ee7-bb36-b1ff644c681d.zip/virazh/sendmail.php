<?php
require('header.php');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
	echo '<p class="text-center">Для отправки отзыва перейдите на страницу <a href="mailform.php">Обратная связь</a>.</p>';
	require('footer.php');
	exit;
}

$raiting = $_POST['raiting'] ?? '';
$specific = $_POST['specific'] ?? '';
$comments = trim($_POST['comments'] ?? '');
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');

if (empty($name) || empty($email) || empty($phone) || empty($comments) || empty($raiting)) {
	echo '<div class="alert alert-danger">Не все заполнены!</div>';
	require('footer.php');
	exit;
}

switch ($raiting) {
	case 'five':
		$mark = 'отлично';
		break;
	case 'four':
		$mark = 'хорошо';
		break;
	case 'three':
		$mark = 'так-себе';
		break;
	case 'two':
		$mark = 'ужасно';
		break;
	default:
		$mark = 'не указана';
		break;
}

switch ($specific) {
	case 'site':
		$tema = 'о сайте';
		break;
	case 'company':
		$tema = 'о компании';
		break;
	case 'production':
		$tema = 'о продукции';
		break;
	case 'servis':
		$tema = 'о сервисе';
		break;
	case 'other':
	default:
		$tema = 'по общим вопросам';
		break;
}

$mailcontent = "ФИО клиента: " . $name . "\n"
	. "Email-адрес клиента: " . $email . "\n"
	. "Телефон: " . $phone . "\n"
	. "Оценка сайта: " . $mark . "\n"
	. "Комментарии клиента " . $tema . ": " . $comments . "\n";

if (isset($_POST['speed'])) {
	$mailcontent .= "Прошу ответить на мой отзыв срочно.\n";
}

$toaddress = 'main@puu.tpc';
$subject = 'Обратная связь от Web-сайта';
@mail($toaddress, $subject, $mailcontent);

$cleanName = str_replace(["\r", "\n", "\t"], ' ', $name);
$cleanComments = str_replace(["\r", "\n", "\t"], ' ', $comments);
$comment = date('H:i, j. m. Y') . "\t" . $cleanName . "\t" . $tema . "\t" . $cleanComments . "\n";
file_put_contents('comments.txt', $comment, FILE_APPEND);
?>
<div class="card shadow-sm">
	<div class="card-body p-4">
		<div class="text-center mb-3">
			<h2 class="h4">Реакция передана</h2>
			<p>Сообщение с вашей реакцией отправлено.</p>
		</div>
		<div>
			<?= nl2br(htmlspecialchars($mailcontent, ENT_QUOTES, 'UTF-8')) ?>
		</div>
	</div>
</div>
<?php
require('footer.php');
?>
