</main>
<footer class="site-footer">
	У нас большой выбор запчастей для отечественных автомобилей и иномарок
</footer>
</body>
</html>
