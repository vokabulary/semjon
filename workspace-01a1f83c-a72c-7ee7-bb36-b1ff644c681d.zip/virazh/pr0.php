<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<title>Практическая работа 0 — Циклы while, do-while, for</title>
	<style>
		body {
			font-family: "Times New Roman", Times, serif;
			margin: 24px;
			color: #111;
		}
		h2 {
			margin-top: 24px;
			margin-bottom: 10px;
			font-size: 18px;
		}
		select {
			padding: 4px 8px;
			font-size: 14px;
		}
		table {
			border-collapse: collapse;
			margin-top: 8px;
		}
		td {
			border: 1px solid #333;
			padding: 6px 10px;
			text-align: center;
			font-size: 14px;
			white-space: nowrap;
		}
	</style>
</head>
<body>
	<h1>Управляющие конструкции. Циклы while, do-while, for</h1>

	<h2>1. Список лет с 1900 до 2023 (цикл while)</h2>
<?php
echo "\t<select name=\"year\">\n";
$year = 1900;
while ($year <= 2023) {
	echo "\t\t<option value=\"$year\">$year</option>\n";
	$year++;
}
echo "\t</select>\n";
?>

	<h2>2. Таблица умножения от 1 до 10 (циклы for)</h2>
<?php
echo "\t<table>\n";
for ($i = 1; $i <= 10; $i++) {
	echo "\t\t<tr>\n";
	for ($j = 1; $j <= 10; $j++) {
		$res = $i * $j;
		echo "\t\t\t<td>$i * $j = $res</td>\n";
	}
	echo "\t\t</tr>\n";
}
echo "\t</table>\n";
?>

	<h2>3. Таблица квадратов чисел от 10 до 99</h2>
<?php
echo "\t<table>\n";
for ($tens = 1; $tens <= 9; $tens++) {
	echo "\t\t<tr>\n";
	for ($units = 0; $units <= 9; $units++) {
		$num = $tens * 10 + $units;
		$sq = $num * $num;
		echo "\t\t\t<td>{$num}<sup>2</sup>=$sq</td>\n";
	}
	echo "\t\t</tr>\n";
}
echo "\t</table>\n";
?>
</body>
</html>
