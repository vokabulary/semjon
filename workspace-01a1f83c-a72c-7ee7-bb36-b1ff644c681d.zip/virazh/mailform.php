<?php
require('header.php');
?>
<div class="row justify-content-center">
	<div class="col-md-7 col-lg-6">
		<div class="card shadow-sm">
			<div class="card-body p-4">
				<h2 class="h4 mb-3">Ваше мнение очень важно для нас</h2>
				<form action="sendmail.php" method="post">
					<div class="mb-3">
						<label class="form-label d-block">Как вы оцениваете сайт?</label>
						<div class="form-check form-check-inline">
							<input class="form-check-input" type="radio" name="raiting" id="raiting_five" value="five" checked>
							<label class="form-check-label" for="raiting_five">Отлично</label>
						</div>
						<div class="form-check form-check-inline">
							<input class="form-check-input" type="radio" name="raiting" id="raiting_four" value="four">
							<label class="form-check-label" for="raiting_four">Хорошо</label>
						</div>
						<div class="form-check form-check-inline">
							<input class="form-check-input" type="radio" name="raiting" id="raiting_three" value="three">
							<label class="form-check-label" for="raiting_three">Так-себе</label>
						</div>
						<div class="form-check form-check-inline">
							<input class="form-check-input" type="radio" name="raiting" id="raiting_two" value="two">
							<label class="form-check-label" for="raiting_two">Ужасно</label>
						</div>
					</div>

					<div class="mb-3">
						<label for="specific" class="form-label">Что вы хотите прокомментировать?</label>
						<select class="form-select" name="specific" id="specific">
							<option value="site">О сайте</option>
							<option value="company">О компании</option>
							<option value="production">О продукции</option>
							<option value="servis">О сервисе</option>
							<option value="other">По общим вопросам</option>
						</select>
					</div>

					<div class="mb-3">
						<label for="comments" class="form-label">Пожалуйста, оставьте свой комментарий ниже:</label>
						<textarea class="form-control" name="comments" id="comments" rows="4"></textarea>
					</div>

					<h3 class="h6 mt-4 mb-3">Как нам связаться с вами?</h3>
					<div class="mb-3 row align-items-center">
						<label for="name" class="col-sm-3 col-form-label">Имя:</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" name="name" id="name">
						</div>
					</div>
					<div class="mb-3 row align-items-center">
						<label for="email" class="col-sm-3 col-form-label">E-mail:</label>
						<div class="col-sm-9">
							<input type="email" class="form-control" name="email" id="email">
						</div>
					</div>
					<div class="mb-3 row align-items-center">
						<label for="phone" class="col-sm-3 col-form-label">Телефон:</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" name="phone" id="phone">
						</div>
					</div>

					<div class="form-check mb-4">
						<input class="form-check-input" type="checkbox" name="speed" id="speed" value="yes">
						<label class="form-check-label" for="speed">Прошу ответить на мой отзыв как можно скорее</label>
					</div>

					<div class="d-flex gap-2">
						<input type="submit" class="btn btn-primary flex-grow-1" value="Отправить">
						<input type="reset" class="btn btn-outline-secondary" value="Очистить">
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php
require('footer.php');
?>
