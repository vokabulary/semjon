<?php
require('header.php');

$allowed = array('pdf', 'png', 'jpg');

if (isset($_FILES['file']) && $_FILES['file']['size'] != 0) {
	$fileName = $_FILES['file']['name'];
	$dotPos = strrpos($fileName, '.');
	$ext = ($dotPos !== false) ? strtolower(substr($fileName, $dotPos + 1)) : '';

	$namefile = date("Y-m-d H-i-s") . '.' . $ext;

	if (!is_dir('upload')) {
		mkdir('upload', 0777, true);
	}

	if ($_FILES['file']['size'] > 10000000) {
		echo '<h2>Слишком большой файл</h2>';
	} elseif (!in_array($ext, $allowed)) {
		echo '<h2>Недопустимый формат</h2>';
	} else {
		move_uploaded_file($_FILES['file']['tmp_name'], "upload/$namefile");
		echo '<h2>Спасибо за предоплату! Ваш заказ будет отправлен в течении двух дней.</h2>';
	}
} else {
	echo '<h2>Вы не прикрепили чек об оплате, можно оплатить заказ при получении.<br>Спасибо за заказ!</h2>';
}

require('footer.php');
?>
