<?php
require('header.php');
?>
<div class="row justify-content-center">
	<div class="col-md-6 col-lg-5">
		<div class="card shadow-sm">
			<div class="card-body p-4">
				<h2 class="text-center mb-4">Форма заказа</h2>
				<form action="processorder.php" method="post">
					<div class="mb-3">
						<label for="tireqty" class="form-label">Автопокрышки</label>
						<input type="number" class="form-control" id="tireqty" name="tireqty" min="0" value="0" required>
					</div>
					<div class="mb-3">
						<label for="oilqty" class="form-label">Машинное масло</label>
						<input type="number" class="form-control" id="oilqty" name="oilqty" min="0" value="0" required>
					</div>
					<div class="mb-3">
						<label for="sparkqty" class="form-label">Свечи зажигания</label>
						<input type="number" class="form-control" id="sparkqty" name="sparkqty" min="0" value="0" required>
					</div>
					<div class="mb-3">
						<label for="address" class="form-label">Адрес доставки</label>
						<input type="text" class="form-control" id="address" name="address" placeholder="Например: Комсомольская 165" required>
					</div>
					<div class="mb-4">
						<label for="find" class="form-label">Как вы нашли компанию "Автозапчасти Вираж?"</label>
						<select class="form-select" id="find" name="find">
							<option value="a">Я регулярный клиент</option>
							<option value="b">В телевизионной рекламе</option>
							<option value="c">В телефонном справочнике</option>
							<option value="d">Кто-то порекомендовал</option>
						</select>
					</div>
					<div class="d-grid">
						<button type="submit" class="btn btn-primary">Отправить заказ</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php
require('footer.php');
?>
