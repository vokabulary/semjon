<?php
require('header.php');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
	echo '<div class="text-center py-4">';
	echo '<h2>Список вашего заказа</h2>';
	echo '<p class="text-muted">Сначала заполните <a href="orderform.php">форму заказа</a>.</p>';
	echo '</div>';
	require('footer.php');
	exit;
}

// создать короткие имена переменных
$tireqty = (int)($_POST['tireqty'] ?? 0);
$oilqty = (int)($_POST['oilqty'] ?? 0);
$sparkqty = (int)($_POST['sparkqty'] ?? 0);
$find = $_POST['find'] ?? '';
$address = trim(str_replace(["\r", "\n", "\t"], ' ', $_POST['address'] ?? ''));

define('TIREPRICE', 5000);
define('OILPRICE', 1000);
define('SPARKPRICE', 500);

$date = date('H:i, j. m. Y');

if ($tireqty <= 5) {
	$discount = 0;
} elseif ($tireqty >= 6 && $tireqty <= 10) {
	$discount = 5;
} elseif ($tireqty >= 11 && $tireqty <= 50) {
	$discount = 10;
} elseif ($tireqty > 50) {
	$discount = 15;
}

$totalamount = ($tireqty * TIREPRICE * (1 - $discount / 100))
	+ ($oilqty * OILPRICE)
	+ ($sparkqty * SPARKPRICE);
$totalamount = number_format($totalamount, 2);
?>
<div class="row justify-content-center">
	<div class="col-md-7 col-lg-6">
		<div class="card shadow-sm">
			<div class="card-body p-4 text-center">
				<h2 class="mb-3">Список вашего заказа</h2>
				<p><?= "Заказ обработан в $date" ?></p>
				<p><?= "Адрес доставки: " . htmlspecialchars($address, ENT_QUOTES, 'UTF-8') ?></p>
				<?php
				switch ($find) {
					case 'a':
						echo '<p>Регулярный клиент</p>';
						break;
					case 'b':
						echo '<p>Клиент обратившейся после телевизионной рекламы</p>';
						break;
					case 'c':
						echo '<p>Клиент, обратившийся в результате нахождения информации в телефонном справочнике</p>';
						break;
					case 'd':
						echo '<p>Клиент, обратившийся по чьей-то устной рекомендации</p>';
						break;
				}
				?>
				<p><?= "Автопокрышек: $tireqty" ?></p>
				<p><?= "Моторное масло: $oilqty" ?></p>
				<p><?= "Свечи зажигания: $sparkqty" ?></p>

				<div class="alert alert-success my-3" role="alert" style="color: green;">
					На заказанное количество автопокрышек предоставляется скидка <?= $discount ?>%
				</div>

				<p class="fw-bold"><?= "Итого: $totalamount руб." ?></p>

				<?php
				$outputstring = $date . "\t" . $tireqty . "\t" . $oilqty . "\t" . $sparkqty . "\t" . $totalamount . "\t" . $address . "\n";
				@$fp = fopen("orders.txt", "a");
				if (!$fp) {
					echo '<p class="text-danger">В настоящее время ваш заказ не может быть сохранен. Пожалуйста, попытайтесь позже.</p>';
				} else {
					fwrite($fp, $outputstring);
					fclose($fp);
				}
				?>

				<hr class="my-4">
				<p class="fw-semibold">Ваш заказ принят. Пожалуйста, прикрепите чек об оплате</p>
				<form action="payment.php" method="post" enctype="multipart/form-data" class="mt-3">
					<div class="mb-3">
						<label for="file" class="form-label">Прикрепить чек</label>
						<input type="file" class="form-control" name="file" id="file">
					</div>
					<button type="submit" class="btn btn-primary">Отправить чек</button>
				</form>
			</div>
		</div>
	</div>
</div>
<?php
require('footer.php');
?>
