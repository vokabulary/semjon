<?php
session_start();

if (!isset($_SESSION['count'])) {
	$_SESSION['count'] = 1;
} else {
	$_SESSION['count']++;
}

require('header.php');
?>
<div class="text-center py-5">
	<h1 class="mb-3">Автовираж</h1>
	<p class="fw-semibold">Добрый день! Вы посетили эту страницу <?= $_SESSION['count'] ?>-й раз.</p>
	<p class="text-muted">Добро пожаловать на сайт компании АвтоВИРАЖ. Пожалуйста, уделите некоторое время на знакомство с нами.</p>
	<div class="mt-4 d-flex justify-content-center gap-3">
		<a href="orderform.php" class="btn btn-primary">Оформить заказ</a>
		<a href="mailform.php" class="btn btn-outline-primary">Обратная связь</a>
	</div>
</div>
<?php
require('footer.php');
?>
