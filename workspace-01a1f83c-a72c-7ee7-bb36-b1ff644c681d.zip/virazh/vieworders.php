<?php
require('header.php');
?>
<h2 class="mb-4">Заказы клиентов</h2>
<?php
@$fp = fopen("orders.txt", "r");
if (!$fp) {
	echo "<p>Нет ожидающих заказов. Пожалуйста, попытайтесь позже.</p>";
	require('footer.php');
	exit;
}

$hasOrders = false;
$rowsHtml = '';
while (!feof($fp)) {
	$orders = fgets($fp);
	if ($orders === false) {
		break;
	}
	$arr_orders = explode("\t", trim($orders, "\r\n"));
	if (!empty($arr_orders[0]) && count($arr_orders) >= 6) {
		$hasOrders = true;
		$rowsHtml .= "<tr>\n";
		$rowsHtml .= "\t<td>" . htmlspecialchars($arr_orders[0], ENT_QUOTES, 'UTF-8') . "</td>\n";
		$rowsHtml .= "\t<td>" . htmlspecialchars($arr_orders[5], ENT_QUOTES, 'UTF-8') . "</td>\n";
		$rowsHtml .= "\t<td>" . htmlspecialchars($arr_orders[1], ENT_QUOTES, 'UTF-8') . "</td>\n";
		$rowsHtml .= "\t<td>" . htmlspecialchars($arr_orders[2], ENT_QUOTES, 'UTF-8') . "</td>\n";
		$rowsHtml .= "\t<td>" . htmlspecialchars($arr_orders[3], ENT_QUOTES, 'UTF-8') . "</td>\n";
		$rowsHtml .= "\t<td>" . htmlspecialchars($arr_orders[4], ENT_QUOTES, 'UTF-8') . "</td>\n";
		$rowsHtml .= "</tr>\n";
	}
}
fclose($fp);

if (!$hasOrders) {
	echo "<p>Нет ожидающих заказов. Пожалуйста, попытайтесь позже.</p>";
} else {
	?>
	<div class="table-responsive">
		<table class="table table-striped table-bordered bg-white shadow-sm">
			<thead class="table-light">
				<tr>
					<th>Дата</th>
					<th>Адрес</th>
					<th>Покрышки</th>
					<th>Масло</th>
					<th>Свечи</th>
					<th>Сумма</th>
				</tr>
			</thead>
			<tbody>
				<?= $rowsHtml ?>
			</tbody>
		</table>
	</div>
	<?php
}

require('footer.php');
?>
