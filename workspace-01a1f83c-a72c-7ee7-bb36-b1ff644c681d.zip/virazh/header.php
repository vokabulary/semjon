<?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Автозапчасти «Вираж»</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<style>
		html, body {
			height: 100%;
		}
		body {
			display: flex;
			flex-direction: column;
			background-color: #f8f9fa;
			font-family: system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif;
		}
		.site-header {
			background: linear-gradient(90deg, #0d6efd 0%, #00a8ff 100%);
			box-shadow: 0 2px 6px rgba(0, 0, 0, 0.12);
		}
		.brand-bar {
			display: flex;
			align-items: center;
			justify-content: center;
			gap: 12px;
			padding: 12px 16px 4px;
			color: #fff;
		}
		.brand-title {
			font-size: 1.35rem;
			font-weight: 700;
			letter-spacing: 0.3px;
			margin: 0;
		}
		.nav-menu {
			display: flex;
			flex-wrap: wrap;
			justify-content: center;
			gap: 8px;
			padding: 8px 16px 12px;
		}
		.nav-menu a {
			color: rgba(255, 255, 255, 0.92);
			text-decoration: none;
			padding: 6px 14px;
			border-radius: 6px;
			font-size: 0.95rem;
			transition: background-color 0.15s ease;
		}
		.nav-menu a:hover {
			background-color: rgba(255, 255, 255, 0.18);
			color: #fff;
		}
		.nav-menu a.active {
			background-color: rgba(255, 255, 255, 0.28);
			color: #fff;
			font-weight: 600;
		}
		.main-content {
			flex: 1 0 auto;
			padding: 32px 16px;
		}
		.site-footer {
			flex-shrink: 0;
			background-color: #d9f2fb;
			color: #1c5d76;
			text-align: center;
			padding: 12px 16px;
			border-top: 1px solid #bee5f3;
			font-size: 0.92rem;
		}
		.avatar {
			display: inline-block;
			padding: 6px 14px;
			font-size: 0.85rem;
			font-weight: 700;
			text-transform: uppercase;
			border-bottom: 1px solid rgba(0, 0, 0, 0.08);
		}
		.avatar-subtle.theme-accent {
			background-color: #ece8ff;
			color: #4b39b5;
		}
	</style>
</head>
<body>
<header class="site-header">
	<div class="brand-bar">
		<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
			<circle cx="12" cy="12" r="9"/>
			<circle cx="12" cy="12" r="3.5"/>
			<line x1="12" y1="3" x2="12" y2="8.5"/>
			<line x1="12" y1="15.5" x2="12" y2="21"/>
			<line x1="3" y1="12" x2="8.5" y2="12"/>
			<line x1="15.5" y1="12" x2="21" y2="12"/>
		</svg>
		<span class="brand-title">Автозапчасти «Вираж»</span>
	</div>
	<nav class="nav-menu">
		<a href="index.php" class="<?= ($currentPage === 'index.php') ? 'active' : '' ?>">Главная</a>
		<a href="orderform.php" class="<?= ($currentPage === 'orderform.php' || $currentPage === 'processorder.php' || $currentPage === 'payment.php') ? 'active' : '' ?>">Оформить заказ</a>
		<a href="mailform.php" class="<?= ($currentPage === 'mailform.php' || $currentPage === 'sendmail.php') ? 'active' : '' ?>">Обратная связь</a>
		<a href="get_comments.php" class="<?= ($currentPage === 'get_comments.php') ? 'active' : '' ?>">Отзывы о нас</a>
		<a href="vieworders.php" class="<?= ($currentPage === 'vieworders.php') ? 'active' : '' ?>">Заказы клиентов</a>
	</nav>
</header>
<main class="main-content container">
