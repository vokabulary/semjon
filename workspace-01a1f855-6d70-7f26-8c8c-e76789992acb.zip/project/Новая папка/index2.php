<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Таблица умножения</title>
</head>
<body>
    <table>
        <?php
        for ($i = 1; $i <= 10; $i++) {
            echo "<tr>";
            for ($j = 1; $j <= 10; $j++) {
                echo "<td>$i * $j = " . ($i * $j) . "</td>";
            }
            echo "</tr>";
        }
        ?>
    </table>
</body>
</html>