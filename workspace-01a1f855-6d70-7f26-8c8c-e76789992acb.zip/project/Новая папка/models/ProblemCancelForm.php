<?php

namespace app\models;

use Yii;

/**
 * ProblemCancelForm is used by the admin to reject a problem (status "Отклонена").
 * Only the rejection reason is required.
 */
class ProblemCancelForm extends \yii\base\Model
{
    public $reason;

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['reason'], 'required', 'message' => 'Укажите причину отклонения заявки'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'reason' => 'Причина отклонения',
        ];
    }
}
