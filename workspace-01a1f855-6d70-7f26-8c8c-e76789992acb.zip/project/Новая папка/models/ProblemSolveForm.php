<?php

namespace app\models;

use Yii;

/**
 * ProblemSolveForm is used by the admin to mark a problem as solved (status "Решена").
 * Requires an "after" photo proving the problem has been fixed.
 */
class ProblemSolveForm extends \yii\base\Model
{
    public $photoAfter;

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['photoAfter'], 'required', 'message' => 'Загрузите фото проблемы после решения.'],
            [['photoAfter'], 'file',
                'extensions' => 'jpg, jpeg, png, bmp',
                'maxSize' => 10 * 1024 * 1024,
                'tooBig' => 'Размер файла не должен превышать 10 МБ',
                'wrongExtension' => 'Допустимые расширения: jpg, jpeg, png, bmp'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'photoAfter' => 'Фото после решения',
        ];
    }
}
