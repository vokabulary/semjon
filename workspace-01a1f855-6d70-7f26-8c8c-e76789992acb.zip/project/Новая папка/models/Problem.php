<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "problem".
 *
 * @property int $id
 * @property string $name
 * @property string $description
 * @property string $time_create
 * @property int $id_user
 * @property int $id_category
 * @property string $status
 * @property string|null $photoBefore
 * @property string|null $photoAfter
 * @property string|null $reason
 *
 * @property Category $category
 * @property User $user
 */
class Problem extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'problem';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'description', 'id_user', 'id_category'], 'required'],
            [['description'], 'string'],
            [['time_create'], 'safe'],
            [['id_user', 'id_category'], 'integer'],
            [['name', 'photoBefore', 'photoAfter'], 'string', 'max' => 255],
            [['status'], 'string', 'max' => 20],
            [['reason'], 'string'],
            [['id_category'], 'exist', 'skipOnError' => true, 'targetClass' => Category::class, 'targetAttribute' => ['id_category' => 'id']],
            [['id_user'], 'exist', 'skipOnError' => true, 'targetClass' => User::class, 'targetAttribute' => ['id_user' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Название',
            'description' => 'Описание',
            'time_create' => 'Время создания',
            'id_user' => 'Пользователь',
            'id_category' => 'Категория',
            'status' => 'Статус',
            'photoBefore' => 'Фото до',
            'photoAfter' => 'Фото после',
            'reason' => 'Причина отклонения',
        ];
    }

    /**
     * Gets query for [[Category]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCategory()
    {
        return $this->hasOne(Category::class, ['id' => 'id_category']);
    }

    /**
     * Gets query for [[User]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::class, ['id' => 'id_user']);
    }
}
