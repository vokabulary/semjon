<?php

namespace app\models;

use Yii;
use yii\web\UploadedFile;

/**
 * ProblemCreateForm represents a problem creation request submitted by a user.
 * It extends Problem and adds file-upload validation for the "before" photo.
 */
class ProblemCreateForm extends Problem
{
    public $photoBefore;

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'description', 'id_category'], 'required'],
            [['photoBefore'], 'file', 'extensions' => 'jpg, jpeg, png, bmp', 'maxSize' => 10 * 1024 * 1024,
                'tooBig' => 'Размер файла не должен превышать 10 МБ',
                'wrongExtension' => 'Допустимые расширения: jpg, jpeg, png, bmp'],
            [['name'], 'string', 'max' => 255],
            [['description'], 'string'],
            [['id_category'], 'integer'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Название проблемы',
            'description' => 'Описание',
            'id_category' => 'Категория',
            'photoBefore' => 'Фото проблемы (до)',
        ];
    }
}
