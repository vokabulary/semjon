<?php require('header.php'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <h1 class="mb-4">Ваше мнение очень важно для нас</h1>
        <form action="sendmail.php" method="post">
            <div class="mb-3">
                <label class="form-label">Как вы оцениваете сайт?</label><br>
                <label><input type="radio" name="rating" value="five" checked> Отлично</label>
                <label class="ms-3"><input type="radio" name="rating" value="four"> Хорошо</label>
                <label class="ms-3"><input type="radio" name="rating" value="three"> Так-себе</label>
                <label class="ms-3"><input type="radio" name="rating" value="two"> Ужасно</label>
            </div>
            <div class="mb-3">
                <label for="specific" class="form-label">Что вы хотите прокомментировать?</label>
                <select class="form-select" id="specific" name="specific">
                    <option value="company">О компании</option>
                    <option value="production">О продукции</option>
                    <option value="servis">О сервисе</option>
                    <option value="other">По общим вопросам</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="comments" class="form-label">Пожалуйста, оставьте свой комментарий ниже:</label>
                <textarea class="form-control" id="comments" name="comments" rows="4"></textarea>
            </div>
            <div class="mb-3">
                <label for="name" class="form-label">Имя:</label>
                <input type="text" class="form-control" id="name" name="name">
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">E-mail:</label>
                <input type="text" class="form-control" id="email" name="email">
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label">Телефон:</label>
                <input type="text" class="form-control" id="phone" name="phone">
            </div>
            <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" id="speed" name="speed">
                <label class="form-check-label" for="speed">Прошу ответить на мой отзыв как можно скорее</label>
            </div>
            <button type="submit" class="btn btn-primary w-100">Отправить отзыв</button>
            <button type="reset" class="btn btn-secondary w-100 mt-2">Очистить</button>
        </form>
    </div>
</div>
<?php require('footer.php'); ?>