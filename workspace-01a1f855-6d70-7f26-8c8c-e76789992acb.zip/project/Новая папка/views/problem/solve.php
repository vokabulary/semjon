<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var app\models\ProblemSolveForm $model */
/** @var app\models\Problem $problem */

$this->title = 'Решить заявку #' . $problem->id;
$this->params['breadcrumbs'][] = ['label' => 'Управление заявками', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="problem-solve">

    <h1><?= Html::encode($this->title) ?></h1>

    <div class="problem-info mb-3">
        <p><strong>Название:</strong> <?= Html::encode($problem->name) ?></p>
        <p><strong>Описание:</strong> <?= Html::encode($problem->description) ?></p>
        <p><strong>Текущий статус:</strong> <?= Html::encode($problem->status) ?></p>
        <?php if ($problem->photo_before): ?>
            <p><strong>Фото "ДО":</strong> <?= Html::img(Yii::getAlias('@web/' . $problem->photo_before), ['class' => 'img-fluid', 'style' => 'max-width: 300px;']) ?></p>
        <?php endif; ?>
    </div>

    <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); ?>

    <?= $form->field($model, 'photoAfter')->fileInput()->label('Загрузите фото "ПОСЛЕ" (доказательство решения)') ?>

    <div class="form-group">
        <?= Html::submitButton('Отметить как решённую', ['class' => 'btn btn-success']) ?>
        <?= Html::a('Отмена', ['index'], ['class' => 'btn btn-secondary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
