<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var app\models\ProblemCancelForm $model */
/** @var app\models\Problem $problem */

$this->title = 'Отклонить заявку #' . $problem->id;
$this->params['breadcrumbs'][] = ['label' => 'Управление заявками', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="problem-cancel">

    <h1><?= Html::encode($this->title) ?></h1>

    <div class="problem-info mb-3">
        <p><strong>Название:</strong> <?= Html::encode($problem->name) ?></p>
        <p><strong>Описание:</strong> <?= Html::encode($problem->description) ?></p>
        <p><strong>Текущий статус:</strong> <?= Html::encode($problem->status) ?></p>
    </div>

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'reason')->textarea(['rows' => 4, 'placeholder' => 'Укажите причину отклонения'])->label('Причина отклонения') ?>

    <div class="form-group">
        <?= Html::submitButton('Отклонить заявку', ['class' => 'btn btn-danger']) ?>
        <?= Html::a('Отмена', ['index'], ['class' => 'btn btn-secondary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
