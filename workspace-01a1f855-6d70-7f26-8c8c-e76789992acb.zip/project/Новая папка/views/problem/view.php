<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/** @var yii\web\View $this */
/** @var app\models\Problem $model */

$this->title = $model->name;
$this->params['breadcrumbs'][] = ['label' => 'Управление заявками', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="problem-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Назад', ['index'], ['class' => 'btn btn-secondary']) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'name',
            'description:ntext',
            'time_create',
            [
                'attribute' => 'id_user',
                'value' => $model->user ? $model->user->login : '-',
            ],
            [
                'attribute' => 'id_category',
                'value' => $model->category ? $model->category->name : '-',
            ],
            'status',
            'photo_before',
            'photo_after',
            'reason',
        ],
    ]) ?>

</div>
