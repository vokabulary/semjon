<?php

use app\models\Problem;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;

/** @var yii\web\View $this */
/** @var app\models\ProblemSearch $searchModel */
/** @var yii\data\ActiveDataProvider $dataProvider */

$this->title = 'Управление заявками';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="problem-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'name',
            'description:ntext',
            'time_create',
            [
                'attribute' => 'id_category',
                'value' => function ($model) {
                    return $model->category ? $model->category->name : '-';
                },
            ],
            'status',
            [
                'attribute' => 'id_user',
                'value' => function ($model) {
                    return $model->user ? $model->user->login : '-';
                },
            ],
            [
                'class' => ActionColumn::class,
                'template' => '{view} {solve} {cancel}',
                'urlCreator' => function ($action, Problem $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'id' => $model->id]);
                },
                'buttons' => [
                    'view' => function ($url, $model, $key) {
                        return Html::a('Посмотреть', $url, ['class' => 'btn btn-primary btn-sm']);
                    },
                    'solve' => function ($url, $model, $key) {
                        if ($model->status !== 'Новая') {
                            return '';
                        }
                        return Html::a('Решить', $url, [
                            'class' => 'btn btn-success btn-sm',
                            'data' => ['confirm' => 'Отметить заявку как решённую? Требуется фото "ПОСЛЕ".'],
                        ]);
                    },
                    'cancel' => function ($url, $model, $key) {
                        if ($model->status !== 'Новая') {
                            return '';
                        }
                        return Html::a('Отклонить', $url, [
                            'class' => 'btn btn-danger btn-sm',
                            'data' => ['confirm' => 'Отклонить заявку? Требуется указать причину.'],
                        ]);
                    },
                ],
            ],
        ],
    ]); ?>

</div>
