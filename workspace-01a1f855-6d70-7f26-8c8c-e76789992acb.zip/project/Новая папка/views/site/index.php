<?php

/** @var yii\web\View $this */

use app\models\Problem;
use yii\helpers\Html;
use yii\helpers\Url;

$this->title = 'Сделаем лучше вместе!';
?>
<div class="site-index">

    <div class="jumbotron text-center bg-transparent mt-5 mb-5">
        <h1 class="display-4">Сделаем лучше вместе!</h1>
        <p class="lead">Портал по приёму заявок жителей на устранение проблем в городе</p>

        <p id="counter">Решено проблем: <span id="counter-value"><?= (int) $solvedCount ?></span></p>
    </div>

    <?php if (!empty($solved)): ?>
        <h2 class="text-center mb-4">Последние решённые проблемы</h2>
        <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-4 g-4">
            <?php foreach ($solved as $problem): ?>
                <div class="col">
                    <div class="card h-100 shadow-sm">
                        <img id="photo-<?= $problem->id ?>"
                             src="<?= Html::encode(Yii::getAlias('@web/' . $problem->photo_after)) ?>"
                             alt="Фото после решения"
                             class="card-img-top"
                             style="cursor: pointer; object-fit: cover; height: 220px;"
                             data-before="<?= Html::encode(Yii::getAlias('@web/' . $problem->photo_before)) ?>"
                             data-after="<?= Html::encode(Yii::getAlias('@web/' . $problem->photo_after)) ?>"
                             onmouseover="hover(<?= $problem->id ?>)"
                             onmouseout="back(<?= $problem->id ?>)">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?= Html::encode($problem->name) ?></h5>
                            <p class="card-text small"><?= Html::encode($problem->description) ?></p>
                            <p class="card-text"><small class="text-muted">
                                    <?= Html::encode($problem->time_create) ?> ·
                                    Категория: <?= Html::encode($problem->category ? $problem->category->name : '-') ?>
                                </small></p>
                            <p class="card-text mt-auto"><span class="badge bg-success">Решена</span></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="text-center mb-4">
            <p class="text-muted">Пока нет решённых проблем.</p>
        </div>
    <?php endif; ?>

    <?php $this->registerJs(<<<JS
var i = 0;
function updateCounter() {
    $.ajax({
        url: '<?= Url::toRoute(['/site/counter']) ?>',
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            var el = $('#counter-value');
            var old = parseInt(el.text(), 10) || 0;
            if (data.count !== old) {
                var audio = new Audio('<?= Url::to('@web/Notif.mp3') ?>');
                audio.play().catch(function (e) { console.log('Audio play blocked:', e); });
                el.css('transform', 'scale(1.4)').text(data.count).css('transform', 'scale(1)');
            }
            i++;
        }
    });
}

function hover(id) {
    var img = $('#photo-' + id);
    var before = img.data('before');
    if (before) {
        img.attr('src', before);
    }
}

function back(id) {
    var img = $('#photo-' + id);
    var after = img.data('after');
    if (after) {
        img.attr('src', after);
    }
}

$(document).ready(function () {
    updateCounter();
    setInterval(updateCounter, 5000);
});
JS
    ) ?>
</div>
