<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var app\models\ProblemCreateForm $model */
/** @var app\models\Category[] $categories */

$this->title = 'Создать заявку';
$this->params['breadcrumbs'][] = ['label' => 'Мои заявки', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="problem-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <div class="row">
        <div class="col-lg-6">
            <?php $form = ActiveForm::begin(['options' => ['enctype' => 'multipart/form-data']]); ?>

            <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'description')->textarea(['rows' => 6]) ?>

            <?= $form->field($model, 'id_category')->dropDownList(
                \yii\helpers\ArrayHelper::map($categories, 'id', 'name'),
                ['prompt' => 'Выберите категорию']
            ) ?>

            <?= $form->field($model, 'photoBefore')->fileInput() ?>

            <div class="form-group">
                <?= Html::submitButton('Создать заявку', ['class' => 'btn btn-success']) ?>
            </div>

            <?php ActiveForm::end(); ?>
        </div>
    </div>

</div>
