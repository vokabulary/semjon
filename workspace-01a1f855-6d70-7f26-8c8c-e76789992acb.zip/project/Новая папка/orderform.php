<?php require('header.php'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <h1 class="mb-4">Форма заказа</h1>
        <form action="processorder.php" method="post">
            <div class="mb-3">
                <label for="tirecount" class="form-label">Автопокрышки</label>
                <input type="number" class="form-control" id="tirecount" name="tirecount" value="1">
            </div>
            <div class="mb-3">
                <label for="oilcount" class="form-label">Машинное масло</label>
                <input type="number" class="form-control" id="oilcount" name="oilcount" value="1">
            </div>
            <div class="mb-3">
                <label for="sparkcount" class="form-label">Свечи зажигания</label>
                <input type="number" class="form-control" id="sparkcount" name="sparkcount" value="1">
            </div>
            <div class="mb-3">
                <label for="client" class="form-label">Адрес доставки</label>
                <input type="text" class="form-control" id="client" name="client" value="Комсомольская 165">
            </div>
            <div class="mb-3">
                <label for="find" class="form-label">Как вы нашли компанию "Автозапчасти Вираж"?</label>
                <select class="form-select" id="find" name="find">
                    <option value="a">Я регулярный клиент</option>
                    <option value="b" selected>В телевизионной рекламе</option>
                    <option value="c">В телефонном справочнике</option>
                    <option value="d">Кто-то порекомендовал</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary w-100">Отправить заказ</button>
        </form>
    </div>
</div>
<?php require('footer.php'); ?>