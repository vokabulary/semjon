<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Годы</title>
</head>
<body>
    <select>
        <?php
        for ($year = 1900; $year <= 2023; $year++) {
            echo "\n\t<option value=\"$year\">$year</option>";
        }
        ?>
    </select>
</body>
</html>