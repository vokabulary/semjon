<?php
require('header.php');

$tireqty  = $_POST['tirecount'];
$oilqty   = $_POST['oilcount'];
$sparkqty = $_POST['sparkcount'];
$find     = $_POST['find'];
$address  = $_POST['client'];

define('TIREPRICE', 5000);
define('OILPRICE', 1000);
define('SPARKPRICE', 500);

$date = date('H:i, j. m. Y');

switch ($find) 
{
    case 'a': $reklama = 'регулярный клиент'; break;
    case 'b': $reklama = 'клиент, обратившийся после телевизионной рекламы'; break;
    case 'c': $reklama = 'клиент, обратившийся в результате нахождения информации в телефонном справочнике'; break;
    case 'd': $reklama = 'клиент, обратившийся по чьей-то устной рекомендации'; break;
}

if ($tireqty < 5) 
{
    $discount = 0;
}
elseif ($tireqty >= 6 && $tireqty <= 10) 
{
    $discount = 5;
} 
elseif ($tireqty >= 11 && $tireqty <= 50) 
{
    $discount = 10;
} 
else 
{
    $discount = 15;
}

$totalamount = $tireqty * TIREPRICE * (1 - $discount / 100)
             + $oilqty * OILPRICE
             + $sparkqty * SPARKPRICE;


$outputstring = $date . "\t" . $tireqty . "\t" . $oilqty . "\t"
              . $sparkqty . "\t" . $totalamount . "\t" . $address . "\r\n";

@ $fr = fopen("orders.txt", "a");
if (!$fr) 
{
    echo "В настоящее время ваш запрос не может быть обработан. Пожалуйста, попытайтесь позже. <br>";
    require('footer.php');
    exit;
}
fwrite($fr, $outputstring);
fclose($fr);
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <h1 class="mb-4">Список вашего заказа</h1>
        <p>Заказ обработан в <?= $date ?></p>
        <p><?= $reklama ?></p>
        <p>Адрес доставки: <?= $address ?></p>
        <p>Автопокрышек: <?= $tireqty ?></p>
        <p>Моторное масло: <?= $oilqty ?></p>
        <p>Свечи зажигания: <?= $sparkqty ?></p>
        <p style="color: green;">Скидка на автопокрышки: <?= $discount ?>%</p>
        <p><strong>Итого: <?= number_format($totalamount, 2) ?> руб.</strong></p>
    </div>
</div>

<?php require('footer.php'); ?>