<?php

namespace app\controllers;

use Yii;
use app\models\Problem;
use app\models\ProblemSearch;
use app\models\ProblemCreateForm;
use app\models\Category;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\UploadedFile;

/**
 * LkController implements the personal cabinet actions for an authorized user.
 */
class LkController extends Controller
{
    /**
     * Only authenticated users may access the personal cabinet.
     */
    public function beforeAction($action)
    {
        if (Yii::$app->user->isGuest) {
            $this->redirect(['/site/login']);
            return false;
        }
        if (!parent::beforeAction($action)) {
            return false;
        }
        return true;
    }

    /**
     * Lists all Problem models of the current user.
     * @return string
     */
    public function actionIndex()
    {
        $searchModel = new ProblemSearch();
        $dataProvider = $searchModel->searchForUser($this->request->queryParams, Yii::$app->user->id);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Problem model.
     * @param int $id ID
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Problem model.
     * If creation is successful, the browser is redirected to the 'index' page.
     * @return string|\yii\web\Response
     */
    public function actionCreate()
    {
        $model = new ProblemCreateForm();
        $categories = Category::find()->all();

        if ($this->request->isPost) {
            $data = $this->request->post('ProblemCreateForm', []);
            $model->name = $data['name'] ?? null;
            $model->description = $data['description'] ?? null;
            $model->id_category = $data['id_category'] ?? null;
            $model->photoBefore = UploadedFile::getInstance($model, 'photoBefore');

            $valid = true;
            if ($model->name === null || $model->name === '') {
                $model->addError('name', 'Название обязательно.');
                $valid = false;
            }
            if ($model->description === null || $model->description === '') {
                $model->addError('description', 'Описание обязательно.');
                $valid = false;
            }
            if ($model->id_category === null || $model->id_category === '') {
                $model->addError('id_category', 'Выберите категорию.');
                $valid = false;
            }
            if ($model->photoBefore === null) {
                $model->addError('photoBefore', 'Загрузите фото проблемы.');
                $valid = false;
            } else {
                $ext = strtolower($model->photoBefore->extension);
                if (!in_array($ext, ['jpg', 'jpeg', 'png', 'bmp'], true)) {
                    $model->addError('photoBefore', 'Допустимые расширения: jpg, jpeg, png, bmp.');
                    $valid = false;
                }
                if ($model->photoBefore->size > 10 * 1024 * 1024) {
                    $model->addError('photoBefore', 'Размер файла не должен превышать 10 МБ.');
                    $valid = false;
                }
            }

            if ($valid && $model->photoBefore !== null) {
                $newFileName = md5($model->photoBefore->baseName . time()) . '.' . $model->photoBefore->extension;
                $path = Yii::getAlias('@app/web/uploads/' . $newFileName);

                if ($model->photoBefore->saveAs($path)) {
                    $problem = new Problem();
                    $problem->name = $model->name;
                    $problem->description = $model->description;
                    $problem->id_user = Yii::$app->user->id;
                    $problem->id_category = $model->id_category;
                    $problem->time_create = date('Y-m-d H:i:s');
                    $problem->status = 'Новая';
                    $problem->photo_before = 'uploads/' . $newFileName;

                    if ($problem->save(false)) {
                        Yii::$app->session->setFlash('success', 'Заявка успешно создана.');
                        return $this->redirect(['/lk']);
                    }
                }
            }
        } else {
            $model->loadDefaultValues();
        }

        return $this->render('create', [
            'model' => $model,
            'categories' => $categories,
        ]);
    }

    /**
     * Deletes an existing Problem model.
     * Only the owner may delete, and only if the status is still "Новая".
     * @param int $id ID
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $model = $this->findModel($id);

        if ($model->id_user != Yii::$app->user->id) {
            Yii::$app->session->setFlash('error', 'Вы можете удалять только свои заявки.');
            return $this->redirect(['index']);
        }

        if ($model->status !== 'Новая') {
            Yii::$app->session->setFlash('error', 'Нельзя удалить заявку, статус которой изменён администратором.');
            return $this->redirect(['index']);
        }

        $model->delete();
        Yii::$app->session->setFlash('success', 'Заявка удалена.');
        return $this->redirect(['index']);
    }

    /**
     * Finds the Problem model based on its primary key value.
     * @param int $id ID
     * @return Problem the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Problem::findOne(['id' => $id])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
