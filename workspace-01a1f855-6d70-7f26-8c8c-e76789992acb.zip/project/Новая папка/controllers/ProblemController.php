<?php

namespace app\controllers;

use Yii;
use app\models\Problem;
use app\models\ProblemSearch;
use app\models\ProblemCancelForm;
use app\models\ProblemSolveForm;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\UploadedFile;

/**
 * ProblemController implements the CRUD actions for Problem model.
 */
class ProblemController extends Controller
{
    /**
     * @inheritDoc
     */
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::class,
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }

    /**
     * Lists all Problem models.
     * @return string
     */
    public function actionIndex()
    {
        $searchModel = new ProblemSearch();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Problem model.
     * @param int $id ID
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Rejects a problem: status "Отклонена" + reason. Only for status "Новая".
     * @param int $id ID
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException
     */
    public function actionCancel($id)
    {
        $problem = $this->findModel($id);
        $model = new ProblemCancelForm();

        if ($this->request->isPost) {
            if ($model->load($this->request->post()) && $model->validate()) {
                if ($problem->status === 'Новая') {
                    $problem->status = 'Отклонена';
                    $problem->reason = $model->reason;
                    if ($problem->save(false)) {
                        Yii::$app->session->setFlash('success', 'Заявка отклонена.');
                        return $this->redirect(['/problem']);
                    }
                } else {
                    Yii::$app->session->setFlash('error', 'Статус заявки изменить невозможно.');
                }
            }
        }

        return $this->render('cancel', [
            'model' => $model,
            'problem' => $problem,
        ]);
    }

    /**
     * Solves a problem: status "Решена" + "after" photo. Only for status "Новая".
     * @param int $id ID
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException
     */
    public function actionSolve($id)
    {
        $problem = $this->findModel($id);
        $model = new ProblemSolveForm();

        if ($this->request->isPost) {
            $model->photoAfter = UploadedFile::getInstance($model, 'photoAfter');
            if ($model->validate() && $model->photoAfter !== null) {
                if ($problem->status === 'Новая') {
                    $newFileName = md5($model->photoAfter->baseName . time()) . '.' . $model->photoAfter->extension;
                    $path = Yii::getAlias('@app/web/uploads/' . $newFileName);

                    if ($model->photoAfter->saveAs($path)) {
                        $problem->status = 'Решена';
                        $problem->photo_after = 'uploads/' . $newFileName;
                        if ($problem->save(false)) {
                            Yii::$app->session->setFlash('success', 'Заявка отмечена как решённая.');
                            return $this->redirect(['/problem']);
                        }
                    }
                } else {
                    Yii::$app->session->setFlash('error', 'Статус заявки изменить невозможно.');
                }
            }
        }

        return $this->render('solve', [
            'model' => $model,
            'problem' => $problem,
        ]);
    }

    /**
     * Creates a new Problem model (admin CRUD).
     * @return string|\yii\web\Response
     */
    public function actionCreate()
    {
        $model = new Problem();

        if ($this->request->isPost) {
            if ($model->load($this->request->post()) && $model->save()) {
                return $this->redirect(['view', 'id' => $model->id]);
            }
        } else {
            $model->loadDefaultValues();
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Problem model.
     * @param int $id ID
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($this->request->isPost && $model->load($this->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Problem model.
     * @param int $id ID
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Problem model based on its primary key value.
     * @param int $id ID
     * @return Problem the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Problem::findOne(['id' => $id])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
