</div> 
    <div style="background-color: #b3e5fc; text-align: center; padding: 15px; margin-top: 50px;">
        <p class="mb-0">У нас большой выбор запчастей для отечественных автомобилей и иномарок</p>
    </div>
</body>
</html>