<?php
require('header.php');

$name     = $_POST['name'];
$email    = $_POST['email'];
$phone    = $_POST['phone'];
$comments = $_POST['comments'];
$rating   = $_POST['rating'];
$specific = $_POST['specific'];

switch ($rating) 
{
    case 'five': $mark = 'отлично'; break;
    case 'four': $mark = 'хорошо'; break;
    case 'three': $mark = 'так-себе'; break;
    case 'two': $mark = 'ужасно'; break;
}

switch ($specific) 
{
    case 'company': $tema = 'о компании'; break;
    case 'production': $tema = 'о продукции'; break;
    case 'servis': $tema = 'о сервисе'; break;
    case 'other': $tema = 'по общим вопросам'; break;
}

$mailcontent = "ФИО клиента: " . $name . "\n"
             . "Email-адрес клиента: " . $email . "\n"
             . "Телефон: " . $phone . "\n"
             . "Оценка сайта: " . $mark . "\n"
             . "Комментарии клиента " . $tema . ": " . $comments . "\n";

if (isset($_POST['speed'])) 
{
    $mailcontent .= "Прошу ответить на мой отзыв срочно.\n";
}


if (empty($name) || empty($email) || empty($phone)) 
{
    echo '<div class="alert alert-danger mt-4">Не все поля заполнены!</div>';
} 
else 
{
    $stoaddress = 'main@puu.tpc';
    $subject = 'Обратная связь от Web-сайта';
    mail($stoaddress, $subject, $mailcontent);

    echo '<div class="text-center mt-4">';
    echo '<h2>Реакция передана</h2>';
    echo '<p>Сообщение с вашей реакцией отправлено.</p>';
    echo '<div class="text-start mt-4">' . nl2br($mailcontent) . '</div>';
    echo '</div>';
}

require('footer.php');
?>