<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Таблица квадратов</title>
</head>
<body>
    <table>
        <?php
        for ($i = 10; $i <= 99; $i++) {
            if (($i - 10) % 10 == 0) {
                echo "<tr>";
            }
            echo "<td>$i<sup>2</sup>=" . ($i * $i) . "</td>";
            if (($i - 9) % 10 == 0) {
                echo "</tr>";
            }
        }
        ?>
    </table>
</body>
</html>
