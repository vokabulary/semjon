<?php 
require('header.php'); 
?>
<div class="row justify-content-center">
    <div class="col-md-10">
        <h1 class="mb-4">Заказы клиентов</h1>

        <?php
        @ $fp = fopen("orders.txt", "r");
        if (!$fp) 
        {
            echo "<p>Нет ожидающих заказов. Пожалуйста, попытайтесь позже.</p>";
        } 
        else 
        {
            echo "<table class='table table-striped table-bordered'>";
            echo "<thead class='table-dark'><tr>
                    <th>Дата</th><th>Адрес</th><th>Покрышки</th><th>Масло</th><th>Свечи</th><th>Сумма</th>
                  </tr></thead><tbody>";

            while (!feof($fp)) {
                $orders = fgets($fp);
                $arr_orders = explode("\t", $orders);
                if ($arr_orders[0] != '') {
                    echo "<tr>
                            <td>" . $arr_orders[0] . "</td>
                            <td>" . $arr_orders[5] . "</td>
                            <td>" . $arr_orders[1] . "</td>
                            <td>" . $arr_orders[2] . "</td>
                            <td>" . $arr_orders[3] . "</td>
                            <td>" . $arr_orders[4] . "</td>
                          </tr>";
                }
            }
            echo "</tbody></table>";
            fclose($fp);
        }
        ?>
    </div>
</div>
<?php require('footer.php'); ?>