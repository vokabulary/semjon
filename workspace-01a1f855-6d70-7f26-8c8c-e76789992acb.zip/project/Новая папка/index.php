<?php
session_start();
if (!isset($_SESSION['count'])) {
    $_SESSION['count'] = 1;
} else {
    $_SESSION['count']++;
}
require('header.php');
?>
<div class="text-center mt-5">
    <h1>Автовираж</h1>
    <p><strong>Добрый день! Вы посетили эту страницу <?php echo $_SESSION['count']; ?> -й раз.</strong></p>
    <p>Добро пожаловать на сайт компании АвтоВИРАЖ. Пожалуйста, уделите некоторое время на знакомство с нами.</p>
</div>
<?php require('footer.php'); ?>