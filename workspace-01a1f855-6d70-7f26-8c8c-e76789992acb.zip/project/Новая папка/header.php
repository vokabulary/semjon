<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <title>Автозапчасти Вираж</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .navbar-custom 
        { 
            background-color: #0d6efd; 
        }
        .navbar-custom .nav-link 
        { 
            color: white; margin-right: 15px; 
        }
        .navbar-custom .nav-link.active 
        { 
            font-weight: bold; 
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container">
            <div class="navbar-nav">
                <a class="nav-link" href="index.php">Главная</a>
                <a class="nav-link" href="orderform.php">Оформить заказ</a>
                <a class="nav-link" href="mailform.php">Обратная связь</a>
                <a class="nav-link" href="vieworders.php">Заказы клиентов</a>
            </div>
        </div>
    </nav>
    <div class="container mt-5">